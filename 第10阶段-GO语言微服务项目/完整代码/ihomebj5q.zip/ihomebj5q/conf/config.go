package conf

//mysql数据库有关配置
const MysqlName = "root"
const MysqlPwd = "123456"
const MysqlAddr = "127.0.0.1"
const MysqlPort = "3306"
const MysqlDB = "ihome"
