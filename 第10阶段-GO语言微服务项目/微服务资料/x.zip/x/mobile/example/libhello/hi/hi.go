// Package hi provides a function for saying hello.
package hi

import "fmt"

func Hello(name string) {
	fmt.Printf("Hello, %s!\n", name)
}
